let chatStyle = () => {

    /* Selecciona el nodo con el id "texto-chat" */
  /* con el método document.getElementById( ) */

  
  
  /* Agrega la clase 'textoChat' con el atributo className */

 

  /* Selecciona el nodo con el id "chat" */
  /* con el método document.getElementById( ) */

  

  /* 
    Utiliza los métodos setAttribute y getAttribute para agregar la clase containerChat a las clases que preexistentes en el nodo  
  */

 

  
}

chatStyle();

// Crear la función tooltipStyle 
// Utiliza el método getElementsByClassName para seleccionar los elementos con la clase 'tooltiptext'
// para agregar la clase 'tooltipStyle'
// A cada nodo, agrega la propiedad visibility con el valor hidden



// Llama a la función tooltipStyle



// tooltipFunctionality

let tooltipFunctionality = () => {
  // Selecciona con la clase 'tituloseccion' 
  let elementos = [] 

  for (let elemento of elementos)  {

    // Agrega un callback manejador al evento onmouseover
    // Teniendo como referencia el nodo elemento, selecciona el primer elemento con la etiqueta 'div'. 
    // A este elemento hijo, modifica la propiedad visibility con el valor 'visible'

    


    // Agrega un listener al evento mouseout
    // Teniendo como referencia el nodo elemento, selecciona el primer elemento con la etiqueta 'div'. 
    // A este elemento hijo, modifica la propiedad visibility con el valor 'hidden'

    

  } 
}


// Llamada a la función tooltipFunctionality
tooltipFunctionality();