let loadUsers = () => {

   
}


//En cuanto el documento esté completamente cargado se ejecutará la función loadUsers
document.addEventListener('DOMContentLoaded', function() {
  loadUsers()
})